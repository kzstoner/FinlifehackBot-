
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor

API_TOKEN = "7231339670:AAHC2b1T5G6ny1wpPTb-mvqA0dXKpgvfIuA"

logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=["start"])
async def send_welcome(message: types.Message):
    await message.reply("Привет! Нажми кнопку ниже, чтобы подать заявку на займ 💸", 
                        reply_markup=types.ReplyKeyboardMarkup(resize_keyboard=True).add("💰 Получить займ"))

@dp.message_handler(lambda message: message.text == "💰 Получить займ")
async def send_loan_link(message: types.Message):
    await message.reply("Вот ссылка для подачи заявки:\nhttps://rdr.sdpdl.com.ua/in/offer/2450?aid=110933")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
